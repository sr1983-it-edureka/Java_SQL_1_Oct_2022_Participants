package com.tcs.core.utils;

public class EmailUtils {

	public static void sendEmail() {
		
	}
}
