
public class DataTypesDemo {

	public static void main(String[] args) {
		
		// Uber Apartments,
		// Indra Nagar,
		// Bangalore,
		// 560075
		
		// Appraisal of an employee for the last 3 years
		// 2021 - A, 2020 - B, 2019 - C
		// A, B, C
		
		int numberOfTransactions = 155;
		
		int sessionDurationInHours = 4;
		
		float interestRate = 7.9F;
		
		char yes = 'Y';
		char no= 'n';
		char percentageSymbol = '%';
		
		boolean tomorrowAHoliday = true;
		
		
		boolean dayAfterTomorrowAHoliday = false;
		boolean day_after_tomorrow_a_holiday = false;
		boolean dayaftertomorrowaholiday = false;
		
		int a = 10;
		int b = 20;
		int boolean1 = 30;
		int true1 = 10;
	}
}
