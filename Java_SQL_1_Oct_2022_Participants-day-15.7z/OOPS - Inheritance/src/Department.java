
public class Department {

}
