package html;

public class HTMLParagraph {

}
