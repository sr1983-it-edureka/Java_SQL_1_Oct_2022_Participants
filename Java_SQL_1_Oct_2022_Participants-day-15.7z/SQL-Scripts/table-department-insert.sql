insert into department (dept_no, dept_name, location) values 
(10, 'ACCOUNTING', 'BANGALORE');
insert into department (dept_no, dept_name, location) values 
(20, 'PRODUCT_DEVELOPMENT', 'CHENNAI');
insert into department (dept_no, dept_name, location) values 
(30, 'PRODUCT_SERVICES', 'DELHI');
insert into department (dept_no, dept_name, location) values 
(40, 'SALES', 'MUMBAI');


