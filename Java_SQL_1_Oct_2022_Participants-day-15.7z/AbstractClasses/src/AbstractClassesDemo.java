
public class AbstractClassesDemo {

	public static void main(String[] args) {
		
		/*
		 * There is blue color table in study-room.
		 * Near to the study-room is the bed-room.
		 * Near to the bedroom, there is a Kitchen.
		 * 
		 */
		
		// Objects
		// blue color table *
		// study-room
		// bed-room
		// Kitchen
		
		/*
		 * Sweta has samsung mobile 
		 * Ram has apple iphone.
		 * 
		 */

		SamsungMobile swetaSamsungMobile =  new SamsungMobile();
		AppleIPhone ramAppleIPhone = new AppleIPhone();
		
//		Mobile rajeshMobile = new Mobile();
		
	}
}
