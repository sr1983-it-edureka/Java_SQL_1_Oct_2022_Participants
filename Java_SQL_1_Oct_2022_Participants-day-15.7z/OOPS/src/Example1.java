
public class Example1 {

	public static void main(String[] args) {
	
		//John installs Netflix application from Google Playstore
		// Mark installs Prime application from Airtel Plyastore
		
		/* Objects: 
			John, Mark
			Netflix,Prime
			GooglePlaystore, AirtelPlaystore
		*/
		
		/* Categories:
		 * Category [Person] {John, Mark}
		 * Category [OTTApplication] {Netflix, Prime}
		 * Category [Playstore] {googlePlaystore, airtelPlaystore}
		 */
		
		/* Actions: (Doing something)
		 * John installing Netflix application
		 * Mark installing Prime application
		 */
	}
	
	
}
