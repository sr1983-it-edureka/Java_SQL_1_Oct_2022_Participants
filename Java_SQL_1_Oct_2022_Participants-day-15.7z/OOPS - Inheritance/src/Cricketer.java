
// ParentClass
// Sub-Class
public class Cricketer extends Player {
		
	float average;
	
	void display() {
		
		super.display();
		System.out.println("Average is " + average);
	}	
}
