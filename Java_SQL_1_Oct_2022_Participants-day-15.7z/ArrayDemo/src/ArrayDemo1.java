public class ArrayDemo1 {

	public static void main(String[] args) {
		
		//A, B, C
		// 2017-2012
		
		char appraisalRating = 'A';
		System.out.println(appraisalRating);
		
		// Index ranges [0 - 4]
		char appraisalRatings [] = {'A', 'B', 'C', 'A', 'C'};
		
		char firstAppraisalElement = appraisalRatings[0];
		System.out.println(firstAppraisalElement);
		
		char fourthAppraisalElement = appraisalRatings[3];
		System.out.println(
				"Fourth element in the array is " + fourthAppraisalElement);
	
	
		
	}
}
