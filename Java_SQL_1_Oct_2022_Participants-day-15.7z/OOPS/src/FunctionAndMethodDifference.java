
public class FunctionAndMethodDifference {

	public static void main(String[] args) {
		
		
		
	}
	
	void functionDemo(){
		
//		printDocument();
		
//		downloadSofware();
	}
	
	void methodDemo() {
		
		// Print a document
		
		// Print a file
				
//		Printer printer01 = null;
				
//		File helloWorldJava = null;
//		printer01.print(helloWorldJava);
	}
}

//class Printer {
//
//	void print(File anyFile){
//		
//	}
//}
//
//class File {
//	
//}
