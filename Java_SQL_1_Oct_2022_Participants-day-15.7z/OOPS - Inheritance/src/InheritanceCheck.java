
public class InheritanceCheck {

	// Example - College & Department
	// College "is-a" department (NO)
	// Department "is-a" College (NO)
	// College contains a number of Department ("contains")
	// Department is part of College ("part-Of")
	public static void main(String[] args) {
		
	}
	
	// Example - Batsman / Bowler
	// Cricketer (PC)
	// CricketBatsman (CC-1)
	// CrickatBowler (CC-2)
	// CricketFielder (
	
	// Rule of Inheritance
	// CC and PC should have "is-a" relationship
	// Batsman (CricketBatsman) is-a Cricketer (YES)
	// Bowler "is-a " cricketer (YES)
	// Tennis-Player "is-a" cricketer (NO)
	
	// DellLaptop is-a Laptop
	// SamsungMobile is-a Mobile
	
	// Laptop is-a Mobile (NO)
	
	// Laptop is-a Device
	// Mobile is-a Device
	
	
	// Cricketer is-a Player
	// Badminton is-a Player
	// Teniss is-a Player
	// Wrestler 
	
	// Multi-level Inheritance
	// Batman is-a Cricketer
	// Cricketer is-a Player
	
}
