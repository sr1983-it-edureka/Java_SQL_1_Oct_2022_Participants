
public class JavaSQLBatch {

	public static void main(String[] args) {
		
		System.out.println("This program will run on for the whole of November...");
	}
}
