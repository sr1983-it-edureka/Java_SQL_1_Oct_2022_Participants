
public class StringDemo {

	public static void main(String[] args) {
		
		String color = "Blue";
				
		color = "RED";
		
		color = "Black";

		String summary = 
			"Today we learnt about constructor" +
			"In addition to constructor, " +
			"we also understood constructor overloading." +
			"Right now, we are also learning how to use String";
		
		System.out.println(summary);
		
		
	}
}
