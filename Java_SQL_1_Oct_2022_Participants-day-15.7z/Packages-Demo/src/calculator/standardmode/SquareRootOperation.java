package calculator.standardmode;

public class SquareRootOperation {

}
