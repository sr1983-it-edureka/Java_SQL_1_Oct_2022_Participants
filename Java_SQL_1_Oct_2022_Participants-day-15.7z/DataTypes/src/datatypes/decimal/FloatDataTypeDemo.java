package datatypes.decimal;

public class FloatDataTypeDemo {

	public static void main(String[] args) {
		
		float percentage = 0.1234F;
		
		System.out.println("Min Value ->" + Float.MIN_VALUE);
		System.out.println("Max Value ->" + Float.MAX_VALUE);
		
		System.out.println("Memmory ->" + Float.SIZE);
	}
}
