package com.edureka.javasql1.strutsdemo;

import org.apache.struts.action.ActionForm;

public class WelcomeModel extends ActionForm{

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
