create table department (
	dept_no integer,
    dept_name varchar(20),
    location varchar(20),
    primary key (dept_no)
);