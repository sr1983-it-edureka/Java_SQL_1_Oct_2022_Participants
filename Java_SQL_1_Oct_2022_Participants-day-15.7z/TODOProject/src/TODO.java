
public class TODO {

	//NOT DONE
		// usage of static method
		// HashSet -> hash
		// 
		// Map - print keys and values - v2
		// Access modifiers (public, private,)
	// Break & continue Usage
	// Eclipse project -> adding another project as depndency
	// @Override
	// throw and throws - Exception
	// Custom Exception
	// Static methods & varaibles
	// Protected scope
	// Ternary Operator usage
	// Serializatio -Object Read (when to stop)

	// DONE
	// Scanner.next / hasNext
	//	String.format
	// Usage of this
	//  Usage of toString

}
