
public class DuplicateFunctionNamesDemo {

	public static void main(String[] args) {
		
	}
	
	int myFunction() {
		return 0;
	}
	
	int myFunction(int a) {
		return -1;
	}
}
