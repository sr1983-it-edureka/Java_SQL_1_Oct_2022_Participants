
public class CharacterDataTypeDemo {

	public static void main(String[] args) {
		
		char a = 'A';
		char percentageSymbol = '%';
		char whiteSpace = ' ';
		
		System.out.println("Memory ->  " + Character.SIZE);
		
		System.out.println("Min Value ->" 
				+ Character.MIN_VALUE);
		System.out.println("Max Value ->" 
				+ Character.MAX_VALUE);
		
	}
}
