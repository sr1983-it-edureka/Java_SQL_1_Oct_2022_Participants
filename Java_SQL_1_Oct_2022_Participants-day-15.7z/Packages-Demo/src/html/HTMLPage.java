package html;

public class HTMLPage {

}
