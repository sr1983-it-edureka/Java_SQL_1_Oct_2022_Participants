package datatypes.decimal;

public class DecimalCategoryDataTypesDemo {

	public static void main(String[] args) {
		
		// Decimals
			// Float, Double
	}
}
