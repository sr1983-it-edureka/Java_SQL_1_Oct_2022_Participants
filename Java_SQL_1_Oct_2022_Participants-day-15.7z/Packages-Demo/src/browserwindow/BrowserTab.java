package browserwindow;

public class BrowserTab {

}
