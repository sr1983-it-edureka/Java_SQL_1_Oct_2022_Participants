
public class College {

}
