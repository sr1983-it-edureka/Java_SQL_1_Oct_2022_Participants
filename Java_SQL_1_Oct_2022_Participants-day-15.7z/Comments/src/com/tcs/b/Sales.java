package com.tcs.b;

import com.tcs.a.Department;
import com.tcs.a.Employee;

/**
 * 
 * @author labuser
 *
 */
public class Sales {

	/**
	 * Some method that illustrates the usage of a method accept two parameters
	 * 
	 * @param d Illustration for the department object
	 * @param e Illustration for the employee object
	 */
	public void perform(Department d, Employee e) {
		
	}
}
