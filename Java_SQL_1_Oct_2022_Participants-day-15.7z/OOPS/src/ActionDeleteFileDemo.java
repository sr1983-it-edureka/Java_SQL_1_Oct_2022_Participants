
public class ActionDeleteFileDemo {

	public static void main(String[] args) {
		
		// Action - 
			// Delete the file 'temp.txt' present in the folder 
			// "C:\temp" on mark's laptop
		
		
		
		/* Objects:
		 *  temp.text, a.text, b.jpg, hello.java)
		 *  "C:\temp", C:\projects, D:\eclipse, E:\eclipse-workspace
		 *  marksLaptop, priyankaLaptopm ronithLaptop,
		 */
		
		/* Category / Class
		 *  File
		 *  Folder (FileLocation)
		 *  Laptop (Device / ElectronicDevice)
		 *  
		 */	
		
		/*
		 * Write class for each Category
		 */
		
		// Primary object
		
		//Action name
		
		// Dependent Elements for the action
		// What all things have to be present?
	}
}
