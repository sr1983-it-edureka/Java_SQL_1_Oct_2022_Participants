public class PrintDocumentDemoV1 {

	public static void main(String[] args) {

		// Action
			// Printer printer-05 printing java-crash-course-pdf-file
		
		
		/* Objects:
		 * 		printer-05
		 * 		java-crash-course-pdf
		 */
		
		/* Category / Class
		 * 		Printer [printer-05, printer-08, printer-04]
		 * 		File [java-pdf, harry-potter-pdf, novel-pdf]
		 */
		
		/* Name of the action
		 * printFile
		 */
		
		// Primary object
			// An object that initiates the action
			// printer-05
		
		// Dependent Objects Identification
			// Dependent Elements for the action
			// What all objects/element have to be present to complete 
			// the action
				// Dependent element - 1
					// java_crash_course_pdf
		
		
		// Translating the action into a programtic representation
		// Format
			// primaryObject.actionName (dependent_elements)
		
		Printer printer_05 = null;
		File java_crash_course_pdf = null;
		
		
		
		// Make the compiler to understand the custom data
			// custom data - printer_05 java_crash_course_pdf
		// Solution
			// For every category, define a class
		
		// Action Name to be represented in the form of functions
	
		// Printer printer-05 printing java-crash-course-pdf-file
		printer_05.printFile(java_crash_course_pdf);
		
	}
	
	void test() {
		
		int johnAge = 35;
		
		int maryFamilyMembersCount = 8;
		
		int a = 10;
			
		int  b = 10;
		
		
	}
	
	void printDemo() {
		
		Printer printer_01;
		
		Printer printer_02;
	}
}
