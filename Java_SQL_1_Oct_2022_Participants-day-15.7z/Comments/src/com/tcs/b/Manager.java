package com.tcs.b;

/**
 * This represents the manager object who manages employees.
 * 
 * 
 * @author Mary
 *
 */
public class Manager {

}
