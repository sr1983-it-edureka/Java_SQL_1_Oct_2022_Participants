package com.tcs.core.utils;

public class FileUtils {

	public static void createFile() {
		
	}
}
