package unary;

public class Logical_NOT {

	public static void main(String[] args) {
		
		boolean a = false;
		
		boolean b = !a;
		
		System.out.println(a);
		System.out.println(b);
	}
}
