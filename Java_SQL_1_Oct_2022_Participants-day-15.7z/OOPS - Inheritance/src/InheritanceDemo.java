
/*
 * Parent (Father / Mother)
 * Child (Daughter / Son)
 * Child inherit something {wealth -> home, car, properties} 
 * from their parent
 */

// Parent - Super / Base 
// Child - Sub / Derived

/*
 * Class (Parent) SOURCE / EXISTING [properties, methods]
 * Class (Child)
 * ChildClass can inherit something {properties, methods} from the 
 * ParentClass COPY
 */
public class InheritanceDemo {

}
