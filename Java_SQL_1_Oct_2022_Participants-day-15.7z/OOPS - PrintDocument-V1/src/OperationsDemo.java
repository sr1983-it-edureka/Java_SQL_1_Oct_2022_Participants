
public class OperationsDemo {

	public static void main(String[] args) {
		
		// int c = a + b;
		
		// IO
		// print("hello")
		
		// IO
		// input_from_user (age)
		
		// int d = subtract(10, 20);
	}
}
