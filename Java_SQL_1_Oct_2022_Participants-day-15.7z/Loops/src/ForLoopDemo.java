
public class ForLoopDemo {

	public static void main(String[] args) {

		for (int counter = 1; counter <=10; counter = counter + 1) {
		
			System.out.println("I want to do exercise regularly");			
		}
	}
}
