
public class FinalKeywordInVariables {

	public static void main(String[] args) {
		
		final double PI = 3.14;
		
//		PI = 3.24;
	}
	
	static void demo1(){
		
		final int age = 11;
		System.out.println("Age is " + age);
		
//		age = 11;		
	}
}
