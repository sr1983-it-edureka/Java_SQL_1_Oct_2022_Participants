
// ChildClass
public class CricketBowler extends Cricketer {
	
	int noOf5Wickets;
	
	void takeWicket() {
		System.out.println("Bowler " + name + " took a wicket");
	}
	
}
