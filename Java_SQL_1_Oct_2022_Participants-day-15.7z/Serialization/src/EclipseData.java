import java.util.ArrayList;

public class EclipseData {

	ArrayList<Project> projects;
	
	public EclipseData() {
		projects = new ArrayList<>();
	}
	
}


