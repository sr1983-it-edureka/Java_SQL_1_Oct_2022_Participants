
public class IDE {

	String name;
	String version;
	
	public IDE(String lName, String lVersion) {
		
		name = lName;
		version = lVersion;
	}
}
