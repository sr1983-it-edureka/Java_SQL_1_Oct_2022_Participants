package com.tcs.core.calculator;

import com.tcs.core.utils.StringUtils;

public class CalculatorUtils {

	public void calculateTax() {
		
		StringUtils stringUtils = new StringUtils();
		
		stringUtils.merge();
	}
	
	public void predictInflation() {
		
	}
}
