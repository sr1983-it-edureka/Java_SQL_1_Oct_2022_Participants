
public class WhileLoopDemo {

	public static void main(String[] args) {
		
		// Repeat for 10 times [Condition]
		// Repeat for 20 times [condition]
		// Complex conditions []
		
		int counter = 1;
		while (counter <= 10) {

			System.out.println("I want to do exercise regularly");

//			counter = counter + 1;
			counter ++;
		}
		
	}
}
