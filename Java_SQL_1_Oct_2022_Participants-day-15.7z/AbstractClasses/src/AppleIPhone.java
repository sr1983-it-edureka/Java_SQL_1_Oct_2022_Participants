
public class AppleIPhone extends Mobile{

	void call() {
		// TODO Auto-generated method stub
		
	}

	void message() {
		// TODO Auto-generated method stub
		
	}

}
