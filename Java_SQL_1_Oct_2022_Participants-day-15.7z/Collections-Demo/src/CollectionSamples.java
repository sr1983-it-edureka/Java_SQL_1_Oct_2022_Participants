import java.util.ArrayList;

public class CollectionSamples {

	static ArrayList<String> softwares(){

		ArrayList<String> softwares = new ArrayList();
		
		softwares.add("Chrome");
		softwares.add("Zoom");
		softwares.add("Skype");

		return softwares;
	}
	
	static ArrayList<Integer> marks(){

		ArrayList<Integer> marks = new ArrayList();
		
		marks.add(90);
		marks.add(80);
		marks.add(95);
		marks.add(62);
		marks.add(76);


		return marks;
	}

}
