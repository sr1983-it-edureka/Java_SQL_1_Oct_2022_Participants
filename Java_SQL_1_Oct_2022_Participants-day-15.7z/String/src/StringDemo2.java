
public class StringDemo2 {

	public static void main(String[] args) {
		
		String redColor = "RED";
		String greenColor = "GREEN";
		
		int a = 10;
		String b = "10abc 10.123";
		String s1 = "10";
		String s2 = "12.34F";
		String s3 = "A";
		String s4 = "true";
		
//		int c = "10";
	}
}
