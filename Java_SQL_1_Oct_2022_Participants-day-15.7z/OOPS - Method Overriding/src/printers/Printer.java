package printers;

// Parent Class
public class Printer {

	void print() {
		
		System.out.println("Printing a document");
	}
}
