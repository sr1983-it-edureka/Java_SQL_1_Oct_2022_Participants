package cts.advertisement;

public class Promotion {

}
