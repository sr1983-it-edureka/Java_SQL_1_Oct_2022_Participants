
public class IfElseDemo {

	public static void main(String[] args) {
		
		// 1 - 7
		// Monday - Sunday
		int dayOfWeek = 2;
		
		if (dayOfWeek == 6 || dayOfWeek == 7 ) {
			System.out.println("Weekend");
		}else {
			System.out.println("Weekday..");
		}
	}
}
