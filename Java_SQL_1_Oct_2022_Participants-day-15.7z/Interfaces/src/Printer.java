
public interface Printer {

	// Actions / Behaviours / 
	void printDocument();
	
	void copyDocument();
	
	void replaceCatridges();
	
}
