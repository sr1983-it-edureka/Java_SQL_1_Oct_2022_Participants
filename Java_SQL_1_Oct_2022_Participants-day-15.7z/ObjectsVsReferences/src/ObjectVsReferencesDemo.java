
public class ObjectVsReferencesDemo {

	public static void main(String[] args) {
		
		String s1 = new String ("Hello");
		
		// s1 as a reference
		// s1  is an object
		
		// Age refers to the data "50"
		int age = 50;
			
		String s2 = new String ("Good Morning");
				
		// s2 refers to the data [Good Morning]
		// s2 refers to the object [Good Morning]
		// s2 is a reference to the object [Good Morning]
	}
}
