package file;

// MovieFile is-a File
public class MovieFile extends File {

	void display() {
		System.out.println("I am going to play this movie. "
				+ "Audiences are going to be entertained..");
	}
}
