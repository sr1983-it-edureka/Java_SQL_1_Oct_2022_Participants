
public class ArrayDeclarationDemo {

	public static void main(String[] args) {
	
		float [] studentMarks = {75.50F, 80.75F, 90.25F};
		
		float studentMarks2 [] = {75.50F, 80.75F, 90.25F};
		
		float studentMarks3[] = new float[3];
		studentMarks3[0] = 75.5F;
		studentMarks3[1] = 80.75F;
		studentMarks3[2] = 90.25F;
		
		float [] studentMarks4 = new float[4];
		
		float [] studentMarks5 = new float[] {75.50F, 80.75F, 90.25F};
		
	}
}
