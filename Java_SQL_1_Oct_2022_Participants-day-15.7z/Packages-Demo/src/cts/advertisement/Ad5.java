package cts.advertisement;

public class Ad5 {

	public static void main(String[] args) {
		
		Advertisment adObj = new Advertisment();
		adObj.packageLevelAccessMethod();
	}
}
