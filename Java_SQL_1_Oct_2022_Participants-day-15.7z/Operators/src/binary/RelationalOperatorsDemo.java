package binary;

public class RelationalOperatorsDemo {

	public static void main(String[] args) {
		
		int a = 20;
		int b = 10;
		
		boolean c = a > b;
//		System.out.println(c);
//		
//		System.out.println(a > b);
//		
//		System.out.println(20 > 40);
		
		System.out.println(20 == 20);
		System.out.println(20 != 40);
		System.out.println(30 != 30);
		System.out.println(40 <= 39);
		System.out.println(54 > 45);
		System.out.println(100 < 100);
		
	}
}
