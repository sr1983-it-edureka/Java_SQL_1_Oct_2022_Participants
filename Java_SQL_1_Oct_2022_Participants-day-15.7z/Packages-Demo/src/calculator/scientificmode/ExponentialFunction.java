package calculator.scientificmode;

public class ExponentialFunction {

}
