package array.totalcountv2;

public interface ArrayTotalCounter {

	void countNumbers(int [] array);
	
	int getResult();
}
