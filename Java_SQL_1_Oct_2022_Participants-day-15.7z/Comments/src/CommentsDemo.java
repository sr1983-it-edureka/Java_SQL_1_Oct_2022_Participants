
public class CommentsDemo {

	// This is a complex algorithm. It has 7 number of steps.
	
	/**
	 * This is a complex algorithm. It has 7 number of steps.
	 */
	public void someComplexAlgorthim() {
		
	}
	
	/* This is an example for multi-line comments.
	 * This method adds two numbers
	 * The result of this addition will be retturned to the caller.
	 */
	/** This is an example for multi-line comments.
	 * This method adds two numbers
	 * The result of this addition will be retturned to the caller.
	 */
	public int add (int a, int b) {
		return a+b;
	}
}
