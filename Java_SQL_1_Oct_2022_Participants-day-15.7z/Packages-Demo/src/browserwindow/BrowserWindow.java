package browserwindow;

public class BrowserWindow {

}
