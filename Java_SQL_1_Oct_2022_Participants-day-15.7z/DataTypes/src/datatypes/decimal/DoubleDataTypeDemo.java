package datatypes.decimal;

public class DoubleDataTypeDemo {

	public static void main(String[] args) {
		
		System.out.println("Min Value ->" + Double.MIN_VALUE);
		System.out.println("Max Value ->" + Double.MAX_VALUE);

		
		System.out.println("Memmory ->" + Double.SIZE);
	}
}
