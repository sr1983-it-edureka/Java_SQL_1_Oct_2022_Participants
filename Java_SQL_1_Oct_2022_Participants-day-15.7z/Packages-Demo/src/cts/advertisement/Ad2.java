package cts.advertisement;

public class Ad2 {

	public static void main(String[] args) {
		
		Advertisment adObj = new Advertisment();
		adObj.runAdvertisement();
				
		System.out.println("Outcome ->" + adObj.overallOutcome);

	}
}
