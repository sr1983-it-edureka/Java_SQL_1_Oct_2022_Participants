
public class Player {

	String name;	
	String sport;
	int noOfMatches;
	
	void display() {
		
		System.out.println("Name is " + name);
		System.out.println("Sport Associated ->" + sport);
		System.out.println("No of Matches " + noOfMatches);
		
		System.out.println();
	}
}
