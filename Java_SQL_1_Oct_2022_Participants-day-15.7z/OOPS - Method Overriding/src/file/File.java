package file;

public class File {

	void display() {
		System.out.println("Displaying contents of the file");
	}
}
