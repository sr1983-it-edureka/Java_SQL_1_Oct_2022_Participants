
public class Hello {
	
	public static void main(String[] args) {
		
		/*
		 * Line 1
		 * 
		 * 
		 * Line 1000
		 */
		System.out.println("Hello Learners - Welcome to Java SQL Training Batch");
	}

}
