
public class AddClient {

	public static void main(String[] args) {
		
		
		Add add = new Add();
		add.doAdd(10, 20);
		add.doAdd(20, 30, 45);
		
		
		
	}
}
