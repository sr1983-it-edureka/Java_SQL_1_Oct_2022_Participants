package datatypes.integer;

public class IntegerCategoryDataTypesDemo {

	public static void main(String[] args) {
		
		// Integer Category
		// int, byte, short, long
		
		
	}
}
