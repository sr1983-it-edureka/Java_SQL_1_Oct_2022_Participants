package browserwindow;

public class BookmarkManager {

}
