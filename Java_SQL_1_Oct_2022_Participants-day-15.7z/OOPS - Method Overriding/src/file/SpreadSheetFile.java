package file;

public class SpreadSheetFile extends File {

	void display() {
		System.out.println("I have lot many calculations and formulas."
			+ "Only technical people will be able to understand my data");
	}
}
