package cts.advertisement;

public class Ad3 {

}
