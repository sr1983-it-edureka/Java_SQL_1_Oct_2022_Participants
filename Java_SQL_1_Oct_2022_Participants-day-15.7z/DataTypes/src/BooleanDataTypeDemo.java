
public class BooleanDataTypeDemo {

	public static void main(String[] args) {
		
//		System.out.println("Memory ->  " + Boolean);		
		
	}
}
