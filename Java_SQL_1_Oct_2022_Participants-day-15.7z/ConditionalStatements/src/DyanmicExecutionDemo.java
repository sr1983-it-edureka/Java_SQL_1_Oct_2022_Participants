
public class DyanmicExecutionDemo {

	public static void main(String[] args) {

		int a = 10;
		a = 155;
		System.out.println(a);

		if (a == 11) {
			int b;
			b = 20;
			System.out.println(b);
		} else {

			int c = 30;
			System.out.println(c);

		}

	}
}
