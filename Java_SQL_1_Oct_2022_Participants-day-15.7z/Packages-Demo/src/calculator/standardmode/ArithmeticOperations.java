package calculator.standardmode;

public class ArithmeticOperations {

}
