package com.tcs.a;

/**
 * This class is called as Department. This class can be used
 * to manage activities in a corporate department. 
 *
 */
public class Department {

	/**
	 * This can be used to upgrade the department.
	 */
	public void upgrade() {
		
	}
}
