package calculator.scientificmode;

public class LogFunction {

}
