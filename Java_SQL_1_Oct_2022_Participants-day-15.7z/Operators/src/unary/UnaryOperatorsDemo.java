package unary;

public class UnaryOperatorsDemo {

	public static void main(String[] args) {
		
		int a = 10;
		System.out.println(a);
		
		a++;
		System.out.println(a);
		

		a--;
		System.out.println(a);
		
		float f = 100.34F;
		f++;
		
		System.out.println(f);
		
		//B - 66, C - 67
		char c = 'A'; // 65
		c++;
		System.out.println(c);
		
		boolean b1 = false;
//		b1 ++;
	}
}
