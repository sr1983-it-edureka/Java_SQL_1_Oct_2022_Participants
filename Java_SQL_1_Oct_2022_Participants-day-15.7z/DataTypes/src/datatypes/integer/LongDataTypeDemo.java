package datatypes.integer;

public class LongDataTypeDemo {

	public static void main(String[] args) {
		
		long populationOfGlobe = 12345678912L;
		
		// Memory 
		// 8 bytes 
		// 64 bits
		// 63 bits
		
		System.out.println("Memory of long " + Long.SIZE);
		
	}
}
