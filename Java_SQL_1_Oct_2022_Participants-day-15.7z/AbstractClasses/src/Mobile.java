
public abstract class Mobile {

	abstract void call();
	
	abstract void message();
}
