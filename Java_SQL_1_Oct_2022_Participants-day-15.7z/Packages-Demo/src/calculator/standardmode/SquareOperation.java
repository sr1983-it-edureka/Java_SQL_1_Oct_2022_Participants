package calculator.standardmode;

public class SquareOperation {

}
